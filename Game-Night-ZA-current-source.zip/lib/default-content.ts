import { TABOO_BANK } from "./taboo-bank-v4";
import { SPELLING_BANK_V2 } from "./spelling-bank-v2";
import { EXPANSION_CONTENT } from "./expansion-content";
import { EXPANSION_BANK_V2 } from "./expansion-bank-v2";
import { PHYSICAL_GAMES_CONTENT } from "./physical-games-content";
import { FIVE_ALIVE_BANK } from "./five-alive-bank";
import { FIFTH_GRADER_BANK_V2 } from "./fifth-grader-bank-v2";
import { CROWD_CLASH_BANK_V2 } from "./crowd-clash-bank-v2";

export const DEFAULT_CONTENT = [
  ...EXPANSION_CONTENT,
  ...EXPANSION_BANK_V2,
  ...PHYSICAL_GAMES_CONTENT,
  ...FIVE_ALIVE_BANK,
  ...SPELLING_BANK_V2.map(([prompt, category]) => ({ gameType:"spelling" as const, prompt, answer:prompt, category, metadata:{} })),
  ...TABOO_BANK.map(([prompt, category, taboo]) => ({
    gameType: "taboo" as const,
    prompt,
    answer: null,
    category,
    metadata: { taboo: [...taboo] },
  })),
  ...FIFTH_GRADER_BANK_V2.map(([category, prompt, answer]) => ({
    gameType: "trivia" as const,
    prompt,
    answer,
    category,
    metadata: {},
  })),
  ...CROWD_CLASH_BANK_V2,
  ...["Ocean","Guitar","Robot","Volcano","Whisper","Diamond","Jungle","Rocket","Shadow","Compass","Thunder","Pirate","Castle","Firework","Mirror","Puzzle","Lantern","Feather","Glacier","Carnival","Marathon","Telescope","Waterfall","Avalanche","Blueprint"].map(prompt => ({ gameType:"password", prompt, answer:prompt, category:"General", metadata:{} })),
  ...["DE","ST","AN","ER","IN","RE","TH","EA","OU","CK","SH","TR","PL","QU","AR","OR","LO","TI","CA","ME","NA","LI","RO","BE","SO"].map(prompt => ({ gameType:"bomb", prompt, answer:null, category:"Fragment", metadata:{} })),
  ...[
    ["Maths","What is 7 × 8?","56"],["Maths","What is half of 250?","125"],["Maths","How many sides does a hexagon have?","6"],["Maths","What is 15% of R200?","R30"],["Natural Science","At what temperature does water boil in Celsius?","100°C"],["Natural Science","How many planets are in our solar system?","8"],["Natural Science","What gas do plants absorb from the air?","Carbon dioxide"],["Geography","How many provinces does South Africa have?","9"],["Geography","Which ocean lies east of South Africa?","Indian Ocean"],["Geography","What is South Africa's official currency?","The Rand"],["History","When is Freedom Day celebrated in South Africa?","27 April"],["History","Who was South Africa's first democratically elected president?","Nelson Mandela"],["History","In what year was South Africa's first democratic election?","1994"],["English","What is the plural of child?","Children"],["English","What is a word with the opposite meaning called?","An antonym"]
  ].map(([category,prompt,answer]) => ({ gameType:"trivia", prompt, answer, category, metadata:{} })),
  ...[
    ["How spicy is this peri-peri?","no kick at all","blow-your-head-off hot"],["How good is this braai?","burnt and sad","legendary"],["How good is this song for a road trip?","skip it","instant classic"],["How scary is this movie?","not scary","sleep with the lights on"],["How famous is this celebrity?","unknown","household name"],["How difficult is this exam?","too easy","impossible"],["How stylish is this outfit?","fashion disaster","red carpet ready"],["How romantic is this gesture?","not romantic","swoon-worthy"],["How healthy is this meal?","pure junk food","super healthy"],["How believable is this excuse for being late?","terrible excuse","totally believable"]
  ].map(([prompt,low,high]) => ({ gameType:"wavelength", prompt, answer:null, category:"Scale", metadata:{ low, high } }))
] as const;
